# Luck Patch Ultimate — Security Scanner & Purchase Lab

Primeiro protótipo Android nativo (Java), independente do código antigo do Lucky Patcher.

## O que esta versão faz
- Permite selecionar um APK pelo seletor de documentos do Android.
- Lê metadados do pacote, SDK alvo, permissões e componentes exportados.
- Sinaliza configurações que merecem revisão: `debuggable`, backup, target SDK antigo, cleartext e componentes exportados sem permissão.
- Faz busca heurística de strings DEX relacionadas a Google Play Billing, URLs, HTTP, recibos e purchase tokens.
- Inclui um Purchase Lab com resultados fictícios (aprovado/recusado/cancelado), sem transações reais.

## Limitações importantes
- Scanner estático/heurístico: não executa o app, não intercepta tráfego e não confirma vulnerabilidades de servidor.
- Não tenta invadir servidores, alterar moedas/saldo de terceiros, falsificar recibos ou contornar pagamentos/licenças.
- A detecção de strings pode produzir falsos positivos e falsos negativos, especialmente com código ofuscado ou bibliotecas nativas.
- Não modifica nem reconstrói APKs nesta primeira versão.

## Como compilar
1. Abra esta pasta no Android Studio (versão compatível com Android Gradle Plugin 8.6.1).
2. Instale Android SDK Platform 35 e JDK 17 ou superior.
3. Aguarde a sincronização do Gradle.
4. Execute `app` em um dispositivo/emulador ou use Build > Build APK(s).

## Próximos passos técnicos
- Parser de Manifest mais completo (incluindo `networkSecurityConfig`, intent filters e providers).
- Relatório exportável JSON/HTML.
- Integração com ambiente de testes do Google Play Billing para apps próprios.
- Backend de demonstração para validar purchase tokens de apps de teste.
- Testes automatizados e análise dinâmica somente em apps/servidores sob autorização.

## Sobre o código histórico
O ZIP histórico LuckyPatcher-6.5.9 fornecido pelo usuário é de 2017 e não contém uma estrutura Gradle pronta. Este protótipo não incorpora código desse repositório; foi criado separadamente para evitar misturar código antigo com licença/proveniência ainda não verificada. Verifique a licença e os direitos antes de redistribuir qualquer código ou marca de terceiros.
