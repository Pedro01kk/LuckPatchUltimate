# Security policy
Use o scanner apenas em APKs e sistemas que você possui ou tem autorização explícita para avaliar. Os resultados são indicadores para revisão, não prova automática de vulnerabilidade. Não use o projeto para fraudar compras, falsificar recibos, obter bens digitais sem pagamento ou acessar servidores sem autorização.
