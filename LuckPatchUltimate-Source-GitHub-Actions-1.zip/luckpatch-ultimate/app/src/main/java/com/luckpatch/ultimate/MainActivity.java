package com.luckpatch.ultimate;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Typeface;
import android.graphics.Color;
import android.util.TypedValue;
import android.database.Cursor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.zip.ZipFile;
import java.util.zip.ZipEntry;
import java.util.Enumeration;

/**
 * Luck Patch Ultimate - defensive APK review and local purchase-flow simulator.
 * This app performs static, heuristic analysis only; it does not exploit apps,
 * alter remote balances, forge receipts, or contact game servers.
 */
public class MainActivity extends Activity {
    private static final int PICK_APK = 41;
    private LinearLayout root;
    private TextView output;
    private StringBuilder report = new StringBuilder();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        append("Luck Patch Ultimate · 1.0.0-alpha1\n" +
                "Análise defensiva de APKs e laboratório de compras fictícias.\n\n" +
                "Selecione um APK para iniciar uma análise estática.\n");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(13, 18, 30));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("LUCK PATCH ULTIMATE");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 23);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Security Scanner  ·  Purchase Lab");
        subtitle.setTextColor(Color.rgb(139, 166, 210));
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(5), 0, dp(18));
        root.addView(subtitle);

        addButton("ANALISAR APK", v -> pickApk());
        addButton("SIMULAR COMPRA LOCAL", v -> showPurchaseLab());
        addButton("LIMPAR RELATÓRIO", v -> { report.setLength(0); output.setText(""); });

        output = new TextView(this);
        output.setTextColor(Color.rgb(225, 232, 245));
        output.setTextSize(13);
        output.setTypeface(Typeface.MONOSPACE);
        output.setPadding(dp(13), dp(14), dp(13), dp(14));
        output.setBackgroundColor(Color.rgb(23, 31, 48));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(16);
        root.addView(output, p);
        setContentView(scroll);
    }

    private void addButton(String label, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(42, 91, 170)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(8);
        root.addView(b, p);
        b.setOnClickListener(click);
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private void append(String s) { report.append(s).append("\n"); output.setText(report.toString()); }

    private void pickApk() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.android.package-archive");
        startActivityForResult(i, PICK_APK);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_APK && result == RESULT_OK && data != null && data.getData() != null) {
            try { analyzeApk(data.getData()); }
            catch (Exception e) { append("[ERRO] Não foi possível analisar: " + e.getMessage()); }
        }
    }

    private void analyzeApk(Uri uri) throws Exception {
        append("\n========================================\nAPK SCANNER\n========================================");
        File apk = copyToCache(uri);
        PackageManager pm = getPackageManager();
        PackageInfo pi = pm.getPackageArchiveInfo(apk.getAbsolutePath(),
                PackageManager.GET_PERMISSIONS | PackageManager.GET_ACTIVITIES |
                PackageManager.GET_SERVICES | PackageManager.GET_RECEIVERS | PackageManager.GET_PROVIDERS);
        if (pi == null || pi.applicationInfo == null) {
            append("[ERRO] O Android não conseguiu interpretar este APK."); return;
        }
        ApplicationInfo ai = pi.applicationInfo;
        ai.sourceDir = apk.getAbsolutePath(); ai.publicSourceDir = apk.getAbsolutePath();
        String appName;
        try { appName = pm.getApplicationLabel(ai).toString(); } catch (Exception ex) { appName = "(nome indisponível)"; }
        append("Aplicativo: " + appName);
        append("Pacote: " + pi.packageName);
        append("Versão: " + (pi.versionName == null ? "?" : pi.versionName) + " (" + pi.versionCode + ")");
        append("SDK mínimo: " + ai.minSdkVersion + " · SDK alvo: " + ai.targetSdkVersion);

        int flags = ai.flags;
        finding((flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0, "ALTO", "APK marcado como debuggable.");
        finding((flags & ApplicationInfo.FLAG_ALLOW_BACKUP) != 0, "INFO", "Backup do app habilitado; avaliar se dados sensíveis podem ser copiados.");
        if (ai.targetSdkVersion < 28) finding(true, "MÉDIO", "Target SDK antigo; revisar comportamento de segurança e compatibilidade.");

        boolean cleartext = false;
        if (android.os.Build.VERSION.SDK_INT >= 24) cleartext = ai.usesCleartextTraffic;
        finding(cleartext, "ALTO", "O manifesto permite tráfego HTTP sem TLS (usesCleartextTraffic).");

        append("\nPermissões declaradas:");
        if (pi.requestedPermissions != null) {
            for (String perm : pi.requestedPermissions) {
                append(" • " + perm);
                String low = perm.toLowerCase(Locale.ROOT);
                if (low.contains("request_install_packages") || low.contains("delete_packages") || low.contains("read_sms") || low.contains("record_audio") || low.contains("access_fine_location"))
                    finding(true, "REVISAR", "Permissão sensível declarada: " + perm);
            }
        } else append(" • Nenhuma permissão declarada.");

        inspectComponents("Activities", pi.activities);
        inspectComponents("Services", pi.services);
        inspectComponents("Receivers", pi.receivers);
        inspectComponents("Providers", pi.providers);

        scanDex(apk);
        append("\n[CONCLUSÃO] Resultado heurístico. Um indicador não prova exploração; confirme manualmente e teste somente apps/ambientes autorizados.");
    }

    private void inspectComponents(String label, ComponentInfo[] components) {
        append("\n" + label + " expostos:");
        if (components == null || components.length == 0) { append(" • Nenhum encontrado."); return; }
        int exposed = 0;
        for (ComponentInfo c : components) if (c.exported) {
            exposed++;
            append(" • " + c.name + (c.permission == null ? " [sem permissão específica]" : " [perm=" + c.permission + "]"));
            if (c.permission == null) finding(true, "REVISAR", "Componente exportado sem permissão declarada: " + c.name);
        }
        if (exposed == 0) append(" • Nenhum componente exportado.");
    }

    private void scanDex(File apk) throws Exception {
        append("\nSinais de compras, APIs e rede (busca textual em DEX):");
        boolean billing = false, urls = false, plainHttp = false, receipt = false;
        ZipFile z = new ZipFile(apk);
        Enumeration<? extends ZipEntry> entries = z.entries();
        while (entries.hasMoreElements()) {
            ZipEntry e = entries.nextElement();
            if (!e.getName().matches("classes([0-9]+)?\\.dex")) continue;
            InputStream in = z.getInputStream(e);
            byte[] buf = new byte[(int)Math.min(Math.max(e.getSize(), 1), 16 * 1024 * 1024)];
            int n = in.read(buf); in.close();
            String s = new String(buf, 0, Math.max(n, 0), "ISO-8859-1");
            String low = s.toLowerCase(Locale.ROOT);
            if (low.contains("com/android/billingclient") || low.contains("inappbillingservice") || low.contains("billingclient")) billing = true;
            if (low.contains("https://") || low.contains("http://")) urls = true;
            if (low.contains("http://")) plainHttp = true;
            if (low.contains("purchase_token") || low.contains("purchasetoken") || low.contains("receipt") || low.contains("verifyreceipt")) receipt = true;
        }
        z.close();
        append(" • Google Play Billing / In-App Billing: " + (billing ? "sinal encontrado" : "não identificado"));
        append(" • Referências a URLs: " + (urls ? "encontradas" : "não identificadas"));
        append(" • Texto HTTP sem TLS em DEX: " + (plainHttp ? "encontrado" : "não identificado"));
        append(" • Termos de recibo/token/validação: " + (receipt ? "encontrados" : "não identificados"));
        append(" • Nota: strings podem estar ausentes, ofuscadas ou não representar fluxos ativos.");
        finding(plainHttp, "REVISAR", "Foi encontrada referência textual a http:// em DEX; confirme se há tráfego real sem TLS.");
        finding(billing, "INFO", "Biblioteca/termos de billing detectados. Isso não indica falha nem permite conceder compras.");
    }

    private void finding(boolean condition, String severity, String message) {
        if (condition) append("[" + severity + "] " + message);
    }

    private File copyToCache(Uri uri) throws Exception {
        File out = new File(getCacheDir(), "selected-analysis.apk");
        InputStream in = getContentResolver().openInputStream(uri);
        FileOutputStream fos = new FileOutputStream(out);
        byte[] b = new byte[8192]; int n;
        while ((n = in.read(b)) > 0) fos.write(b, 0, n);
        in.close(); fos.close(); return out;
    }

    private void showPurchaseLab() {
        append("\n========================================\nPURCHASE LAB · SIMULAÇÃO LOCAL\n========================================");
        append("Este laboratório NÃO chama a Play Store, não cria recibos reais e não altera saldo em jogos.");
        append("[SIMULADO] Compra aprovada → o app de teste deve liberar o item de teste após validação local/mock.");
        append("[SIMULADO] Compra recusada → nenhum item deve ser entregue.");
        append("[SIMULADO] Compra cancelada → nenhum item deve ser entregue.");
        append("[TESTE] Recomendação: no seu próprio app, valide purchaseToken no backend e processe cada transação uma única vez (idempotência).");
    }
}
